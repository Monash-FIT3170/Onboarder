import json

def lambda_handler(event, context):
    response = {
        'statusCode': 200,
        'body': 'test'
    }
    return response
